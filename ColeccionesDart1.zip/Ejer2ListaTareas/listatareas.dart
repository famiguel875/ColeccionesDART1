void main() {
  List<String> listaTareas = [];

  void agregarTarea(String tarea) {
    try {
      if (tarea.isEmpty) {
        throw FormatException('La tarea no puede estar vacía.');
      }

      listaTareas.add(tarea);
      print('Tarea añadida: $tarea');
    } catch (e) {
      print('Error al añadir la tarea: $e');
    }
  }

  void mostrarTareas() {
    try {
      if (listaTareas.isEmpty) {
        print('No hay tareas en la lista.');
      } else {
        print('Lista de tareas:');
        for (var i = 0; i < listaTareas.length; i++) {
          print('${i + 1}. ${listaTareas[i]}');
        }
      }
    } catch (e) {
      print('Error al mostrar las tareas: $e');
    }
  }

  agregarTarea('Estudiar Dart');
  agregarTarea('Hacer ejercicio');
  agregarTarea('Comprar comida');
  mostrarTareas();
}
