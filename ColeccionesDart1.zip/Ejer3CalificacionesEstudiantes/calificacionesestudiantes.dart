void main() {
  Map<String, double> calificaciones = {};

  void agregarCalificacion(String estudiante, double calificacion) {
    try {
      if (estudiante.isEmpty) {
        throw FormatException('El nombre del estudiante no puede estar vacío.');
      }
      if (calificacion < 0 || calificacion > 10) {
        throw RangeError('La calificación debe estar entre 0 y 10.');
      }

      calificaciones[estudiante] = calificacion;
      print('Calificación añadida: $estudiante -> $calificacion');
    } catch (e) {
      print('Error al añadir la calificación: $e');
    }
  }

  void mostrarCalificaciones() {
    try {
      if (calificaciones.isEmpty) {
        print('No hay calificaciones registradas.');
      } else {
        print('Calificaciones de los estudiantes:');
        calificaciones.forEach((estudiante, calificacion) {
          print('$estudiante: $calificacion');
        });
      }
    } catch (e) {
      print('Error al mostrar las calificaciones: $e');
    }
  }

  agregarCalificacion('Ana', 8.5);
  agregarCalificacion('Luis', 9.0);
  mostrarCalificaciones();
}
