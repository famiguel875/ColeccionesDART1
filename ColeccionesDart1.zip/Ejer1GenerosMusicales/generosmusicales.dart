void main() {
  Set<String> generosFavoritos = {};

  void agregarGenero(String genero) {
    try {
      if (genero.isEmpty) {
        throw FormatException('El género no puede estar vacío.');
      }

      if (generosFavoritos.length >= 5) {
        print('Error: No puedes añadir más de 5 géneros favoritos.');
      } else if (!generosFavoritos.add(genero)) {
        print('Error: El género "$genero" ya está en la lista.');
      } else {
        print('Género añadido: $genero');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  agregarGenero('Rock');
  agregarGenero('Pop');
  agregarGenero('Jazz');
  agregarGenero('Blues');
  agregarGenero('Hip-Hop');

  print('Géneros favoritos: $generosFavoritos');
}
